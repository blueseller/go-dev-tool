package good

func random() int {
	y := 6 + 7
	return y
}

func random2(y int) int {
	return y
}
