package baz

import "golang.org/x/tools/internal/lsp/bar"

func Baz() {
	bar.Bar()
}
