package bar

import "golang.org/x/tools/internal/lsp/foo"

func Bar() {
	foo.Foo()
}
