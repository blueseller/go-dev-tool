package foo

func Foo() {}
