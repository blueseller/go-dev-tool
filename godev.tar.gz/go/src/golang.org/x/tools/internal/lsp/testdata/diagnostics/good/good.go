package good

func stuff() {
	x := 5
	random2(x)
}
