// DO NOT EDIT

package pkg

type t struct{}
