// DO NOT EDIT

package pkg

func fn() {
	for true {
	}
}
